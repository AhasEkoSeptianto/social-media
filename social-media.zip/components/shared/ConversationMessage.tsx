import { ArrowLeft, Images, Phone, Send, Video, Ellipsis } from "lucide-react";
import { Button } from "../ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "../ui/card";
import { Separator } from "../ui/separator";
import {
  MessageScroller,
  MessageScrollerContent,
  MessageScrollerItem,
  MessageScrollerProvider,
  MessageScrollerViewport,
} from "../ui/message-scroller";
import { Message, MessageAvatar, MessageContent } from "../ui/message";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Bubble, BubbleContent } from "../ui/bubble";
import { Input } from "../ui/input";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useUser } from "@/hooks/auths/useUser";
import { useConversationMessages } from "@/hooks/chat/useConservationMessage";
import dayjs from "@/lib/day";

interface friendConversation {
  conversationId: string | null;
  avatarUrl: string;
  username: string;
  online_status: string;
  with_back_button?: boolean;
}

export default function ConversationMessage(props: friendConversation) {
  const router = useRouter();
  const { user } = useUser();
  const [input, setInput] = useState("");

  const {
    messages,
    isLoading,
    typingUserIds,
    send,
    notifyTyping,
    notifyStopTyping,
  } = useConversationMessages(props.conversationId, user?.id);

  function handleSend() {
    if (!input.trim()) return;
    send(input);
    setInput("");
    notifyStopTyping();
  }

  function handleChange(value: string) {
    setInput(value);
    if (value.trim()) {
      notifyTyping();
    } else {
      notifyStopTyping();
    }
  }

  return (
    <MessageScrollerProvider autoScroll defaultScrollPosition="last-anchor">
      <Card className="col-span-8 bg-brand">
        <CardHeader className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {props.with_back_button ? (
              <ArrowLeft onClick={() => router.back()} />
            ) : null}
            <Avatar size="lg">
              <AvatarImage src={props?.avatarUrl} alt="@shadcn" />
              <AvatarFallback>CN</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-lg">{props.username}</p>
              <p className="text-white/70 truncate max-w-60 opacity-70">
                {typingUserIds.length > 0
                  ? "sedang mengetik..."
                  : props.online_status}
              </p>
            </div>
          </div>
          <div className="opacity-70 flex items-center space-x-4">
            <Button size="icon" variant="outline" className="cursor-pointer">
              <Phone size={20} />
            </Button>
            <Button size="icon" variant="outline" className="cursor-pointer">
              <Video size={20} />
            </Button>
            <Button size="icon" variant="outline" className="cursor-pointer">
              <Ellipsis size={20} />
            </Button>
          </div>
        </CardHeader>
        <Separator className="mb-2 bg-white/10" />
        <CardContent className="overflow-hidden h-[39rem] ">
          {!props.conversationId ? (
            <div className="h-full flex items-center justify-center text-white/50">
              Pilih percakapan untuk mulai chat
            </div>
          ) : isLoading ? (
            <div className="h-full flex items-center justify-center text-white/50">
              Memuat pesan...
            </div>
          ) : (
            <MessageScroller>
              <MessageScrollerViewport>
                <MessageScrollerContent
                  aria-busy={false}
                  className="p-(--card-spacing)"
                >
                  {messages.map((msg) => {
                    const senderId =
                      typeof msg.sender === "string"
                        ? msg.sender
                        : msg.sender._id;
                    const senderName =
                      typeof msg.sender === "string" ? "" : msg.sender.name;
                    const senderAvatar =
                      typeof msg.sender === "string"
                        ? ""
                        : msg.sender.avatarUrl;
                    const isMe = senderId === user?.id;

                    return (
                      <MessageScrollerItem
                        key={msg._id}
                        messageId={msg._id}
                        scrollAnchor={isMe}
                      >
                        <Message align={isMe ? "end" : "start"}>
                          <MessageAvatar>
                            <Avatar>
                              <AvatarImage
                                src={senderAvatar}
                                alt={senderName}
                              />
                              <AvatarFallback>
                                {isMe ? "Ne" : (senderName?.[0] ?? "?")}
                              </AvatarFallback>
                            </Avatar>
                          </MessageAvatar>
                          <MessageContent>
                            <Bubble>
                              <BubbleContent
                                className={`${isMe ? "!bg-brand5" : "!bg-brand4"} !text-white !text-md`}
                              >
                                {msg.text}
                              </BubbleContent>
                            </Bubble>
                            <p className="text-[10px] text-white/40 mt-1">
                              {dayjs(msg.createdAt).format("HH:mm")}
                            </p>
                          </MessageContent>
                        </Message>
                      </MessageScrollerItem>
                    );
                  })}
                </MessageScrollerContent>
              </MessageScrollerViewport>
            </MessageScroller>
          )}
        </CardContent>
        <CardFooter className="bg-brand flex items-start space-x-4">
          <Button variant="outline">
            <Images />
          </Button>
          <Input
            placeholder="message"
            value={input}
            onChange={(e) => handleChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSend();
            }}
            disabled={!props.conversationId}
          />
          <Button
            variant="outline"
            onClick={handleSend}
            disabled={!props.conversationId}
          >
            <Send />
          </Button>
        </CardFooter>
      </Card>
    </MessageScrollerProvider>
  );
}
