"use client";

import EditProfileForm from "@/components/forms/EditProfileForm";
import NavigationMenuMobile from "@/components/shared/NavigationMenuMobile";
import { AppSidebar } from "@/components/shared/Sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { SidebarProvider } from "@/components/ui/sidebar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUser } from "@/hooks/auths/useUser";
import { logout } from "@/lib/api/auth.api";
import { nextFetcher } from "@/lib/fetcher";
import {
  ArrowLeft,
  Bookmark,
  Camera,
  Grid2X2,
  LogOut,
  Play,
  Settings,
} from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import useSWR from "swr";
interface ExploreItem {
  id: string;
  src: string;
  alt: string;
  isVideo?: boolean;
  span?: "tall"; // buat item yang row-span-2
}

const items: ExploreItem[] = [
  { id: "1", src: "/images/post1.avif", alt: "Mountain sunset", span: "tall" },
  { id: "2", src: "/images/post2.avif", alt: "Green sofa" },
  { id: "3", src: "/images/post3.avif", alt: "Restaurant dish", isVideo: true },
  { id: "4", src: "/images/post4.avif", alt: "Dog closeup" },
  { id: "5", src: "/images/post5.avif", alt: "Eiffel tower", isVideo: true },
  { id: "6", src: "/images/post6.avif", alt: "Pool float" },
  { id: "7", src: "/images/post7.avif", alt: "Ocean waves" },
  { id: "8", src: "/images/post8.avif", alt: "Man portrait" },
];
export default function ProfilePage() {
  const router = useRouter();
  const { user, mutate } = useUser();
  const [onSetting, setOnSetting] = useState(false);
  const onLogout = async () => {
    await logout();
    await mutate();
    router.push("/login");
  };
  const [myPostList, setMyPostList] = useState([]);

  const getProfile = async () => {
    const myPost = await nextFetcher(`/api/posts/get?myPost=true&images=true`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    }).then((resp) => {
      setMyPostList(resp?.data?.posts);
    });
  };

  useEffect(() => {
    getProfile();
  }, []);
  if (onSetting) {
    return (
      <div className="absolute z-50 h-screen w-screen bg-brand p-4 space-y-2">
        <div className="flex items-center space-x-4">
          <ArrowLeft onClick={() => setOnSetting(false)} />
          <p className="text-2xl">Settings</p>
        </div>
        <Separator className="h-3" />
        <div
          className="flex items-center space-x-2 text-danger "
          onClick={onLogout}
        >
          <LogOut />
          <p>Keluar</p>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider className="">
      <div className="hidden lg:block">
        <AppSidebar />
      </div>
      <div className="fixed bottom-0 left-0 z-30 lg:hidden">
        <NavigationMenuMobile />
      </div>

      <div className="absolute top-8 right-8 text-black z-40 lg:hidden">
        <Button size="lg" onClick={() => setOnSetting(true)}>
          <Settings className="rounded-lg" size={50} />
        </Button>
      </div>

      <main className="w-full lg:grid grid-cols-12 p-4 gap-8 ">
        <div className="col-span-2"></div>
        <div className="col-span-9 container space-y-8">
          <div className="relative h-70">
            <div className="bg-[url(/images/post1.avif)] rounded-lg w-full h-60 bg-cover">
              <div className="absolute bottom-0 left-10">
                <Image
                  src={`${user?.avatarUrl ? user?.avatarUrl : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBEQACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAAAgUGAQQHA//EADwQAAEDAwAGBwcCBAcBAAAAAAEAAgMEBREGEiExQVETImFxgZGhBxQyQlLB0bHhI3KCwjNDYpKisvA0/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAEEBQMCBv/EAC4RAAICAgAFAwMDBQEBAAAAAAABAgMEEQUSITFBEzJRImGRcYGxI0Kh0fFDFf/aAAwDAQACEQMRAD8A7igBACAEBjKAjrhe6Ghy2WXWkH+WwZP7LvVjW2dkV7Mmuvuyv1ellQ/IpYGRN4F51ir8OHxXueylPPk/aiInvNxnz0lZLt+k6o9FajjUx7RKssi2XeRpSTyyH+JLI7+ZxK6qEV2Rycm+7PPWI2tcR3L1ojZ6x19ZCcxVc7ccpCvDqrl3ij2rbI9pM36bSi6wfHM2ZvKRo/UYKrzwaZeNfodoZt0fOycoNM6WUhtdC6A/U3rt/Kp2cOnHrB7LlfEIPpNaLJTVMFTE2WnlZJG7c5hyFRlGUHqS0XozjNbi9nsvJ6BACAEAIAQAgBAa1dWwUMJlqZAxvAcSeQHFe4VysfLE8WWRrXNIp910hqazLKcmCE/Ses7vP4WtRhwh1l1Zk3Zk7Okei/yQhV0pikoBCVJApKAUqQKSgFJUgUoQe1FXVVBN0tJM6N3HG53eOK8WVQsWpI912Tre4su1h0sgri2nrdWCoOwHPUf+D2LIycGVf1Q6r/JrY+bGzpPoyzDcqBeMoAQAgBACA0Ltc4bdT68nWedjGDe4/hdqaZXS0jhffGqO2USurp66YzVDsngBuaOQW3VVGuOomLbbKyW5GqSupzEJQCkqSBSeKA9oKKrqhmnpZ5RzZGSPPcvEra4e6SPca5y9sWeslmubBl1BUeDM/ovKyaX2kj26LV/ayPka5ji17XNcN4cMELsmmto5NNPTEJUnkQlSBSUAp3KSC2aLaVGncyiubyYcgRzOO1nIHs7eCzMvCUvrr7/BpYuY4/RPt8l9BBGQsc1jKAEAIDWr6yKhpX1Exw1o3DeTyXuut2S5YniyxVx5pHPrhWy11U6ec9Y7hwaOAC3qqo1x5UYNtjslzM1SV1OYpKAQlSQNBDLUzshgYXyPOA0DevMpxguaXY9Ri5Plj3LtZtGaaka2Wsa2efiHbWN7hx7z6LHvzZz6R6I16MOEOsurLAGgAADAG4BUi7oMBAatfb6Svj1KuBkg4EjaO47wvdds63uL0c7KoWLUkULSPR2W0npoS6WkJ+I/Ew9vZ2raxctXfTLuZGTiOr6l2K+SrpTFJUgUlCBSdgQF20H0hLi211kmTup3uO//AEfhZOfi6/qw/c1MHJ/85/sXgLKNQEBg7kBR9J7l75WGCM5hhJGz5ncT9ls4dHJDmfdmNmXepPlXZfyQhKulMQlAKSpIFJQF20NtjYKT32Ro6WcdXPyt/ff5LGzrnKfIuyNfBo5Yc77ssqol8EAIAQHnPFHNE+KVgfG8Yc08QpTcXtdyJJSWmcovlvNruc1KSS0HLCeLTu/HgvpMe31a1M+evq9KxwI4ldjiKSgFKkGA9zHNexxa5pyHDYQexGk1phNrqjrOi93F4tcc7iOnZ1Jmj6hx8d6+byqPRs5fHg38a71Yb8+SYVcskbf673G2ySNP8R3UZjmf/ZXfGq9S1Ir5Nnp1tnPScbMrfMIUlAISpIFJQGGtMr2xt2F5DR3nYjelslLb0dYhY2JjY2DDWNDQOQC+Zb29n0iWlo9FBIIAQAgA7kBR/aRTgGhqRvOtG7t3Efda3DJe6P7mVxKPWMv2KSStUzBCVIMEoQKSpBYNBbp7he2RPOIar+G7kHfKfPZ4qln0+pVtd0XMK307deGdTByvnjdKdppVF9XDTA9WNmsR2n9h6rX4fDUXP5MrPnuSj8FaJWgZ4pKkgUlAKSpBmGQRTxSO3Me1x8DleZLcWj1F6kmdbbt2hfMn0hlACAEAIAQFK9pUzRT0EOdrnvf5AD+5anDF9UmZnEn0iiiFbBlCkoQKSpAhKkGA9zXB0ZLXtOWuHAo0mtMba6o7ZaaxtwtlNVt2dNG12ORxt9V8rbB12OHwfS1T54KXyUO+zdPd6uTP+YWjuGz7Lbxo8tMUYmRLmukyOJVg4CkoBSVIFJQCE89ylA6TorcRX2qPWcOmhHRyDPLcfEL5/Lp9K1/D7G7iW+pWm+6JlViyCAEAIDB3IDlmmVzFyvL+iIMEA6JhHHG8+f6L6DCp9Orr3ZgZlvqW9OyIElXCqKSpAhKkCkoBSUB072eVzDo6IpHf4Mz2juJ1v7lg8Rg/X38o2uHzXo6+GVeof0k8jz8z3HzK1YLUUjKk9ybPElejyKSpApKAUlSBChBu2a6z2mtE8I1mHZJHnY4flcb6I3R5X+TtRdKmXMjpVsudLc6cTUkgcPmafiaeRCwLaZ1S5ZI3aroWrcWbq5nQEBgnCApel2lTGRyUFrkDpXdWWZhyGjiGnif0Wnh4Tb9SxdDMy8xJclb6lCJ7FsmSKSpAhKkCkoBSUApKkgmbFdzQUskYcRrSF3oB9lVyKPUkmWse704tfc2ndVxbyOF6RyYhKkgUlAKSpApKEG1bbbV3OUx0cRfj4nE4a3vK5W3QqW5M6VUzteoo97lo5c7dCZpoQ+Mb3RHW1e9eKsymx8qfU6W4tta20RlPVT0sonpZnxPG5zDhWJQjNcsls4RnKD5osn6XTe5wtDZmQVAHEgtd5jZ6KjPh1Un0bRdhxC2K+pbPeTT6q1cR0MIPNzyfwvC4ZDzJnp8Sl4iQd00julzYWVFRqRHfHCNVvjxPiVbqxKauqXX7lW3Kts6N/gjqSkqK2dtPSROlldua39TyC7znGC5pvRxhCU3yxW2TFVodeaeAzGGOTAyWRP1neXHwVWHEKJPW9FqWDdGO9FcdkHB4HG1XimKSgFJQCkqSBSUB6wQSTNLmZwDheZSS7nuMXLsWW5M6G4VUZGNWVw9VWqfNXF/Y62rlskvuapK6HMUlSBSdiEG9ZbXLd60QRZbG3bLJj4R+VwyL40Q5mdqKJXS0jplBRQUFMynpWBkbfMnmTxKwLLJWS5pPqb1dca48sexsEZXg9kBdNEbbXOdIxpppT80WMHvG5XKs66tafVFO3Cqse10ZXqjQSta4+71lPI3hrgtP3V2PE4P3RaKkuGz/ALWeDdBrq49aWlaP53H7L2+JUrwzx/8APt+USVDoBEHB1fWvkH0RN1fU5XCfE2/ZH8neHDV/fL8Fqt1so7bF0dFAyJp3kDa7vO8rNstnY9zey/XVCtaijbIyvB0KbppouKuN9wtzAKlu2WNo/wAUc/5v1Wlg5nI1XZ2/gzszF5/rh3Ob5yMhbhjbFJUgUlAISpBetBLQKy0TTPbnNQ4DuDWrJz7nC1JfBqYNSlW2/kbS+n6C+TP3NmaHjywfUL1gz5qUvg5ZsOW5/chCVcKgpKkgw0Oe5rGAlzjgAcSm0lthLb0jqGj1rbareyHAMrhrSu5u/ZfO5FztscvHg+gx6VVWo+SUXA7ggBAGEAYQAgBACAwdyA5Xp9ZRbLkKuBmrTVZJxwY/iPHf5rf4ff6lfI+6/gw86j058y7MqpK0CiISpBgnmgOyaD0bqHRiiY8YfI0yu/qJI9CF8znWepkSf7fg+hw6+SlJ/r+TV07oukoYqxo2wO1XY+l2PvjzXbh1nLNwfk4cQr3BTXgopWyZApKkE5oVRCrvbZHjLKZvSdmtub9z4Kln28lWl5LeFXz27fg6SsI3AQAgBACAEAIAQAgBAQmmNuFy0fqog3Wkjb0sWN+s3aPPaPFWcS30roy/YrZdXqVNHGMg4I3L6c+eMEoDas1A663aloW5xM/Duxo2uPkCud9qqrlP4PdVfqzUfk7sxoYwNYAGtGAOQXye99T6ZISrgjqaaSCVuWSNLSOwr1GThJSXgicVOLi/Jyi40klBWy0s3xxuxn6hwPiF9JVYrIKS8nztlbrm4s1CV0PBa/Z9VRR1dTTSECSVoczPHG8eqzeJwbjGXhGhw+aUnH5L7lY5rggBACAEAIAQAgBACA1LnWQUNBPVVLg2KJhc7PHs7yvdcHZNRj3ZzsmoQcmcHc7WJdjGTnHJfWnzLexCVJB0b2XWbo4pbvO3bKDHBkfL8zvE7PBYnFL9tVLx1Zr8Op0na/Pb9DoCyTUAoCsaZ2Y11MKumbmpgG1oHxs5d44eKv4OR6cuSXZ/yUc3H9SPOu6OeFbiMUGSPikbJG4tewhzXDYQQoaTWmSm09o6JovpRHcmtpqwtjrAMchL2jt7Fh5WHKp80fb/AAbOLlqxcsvcWYKiXgQAgBACAEAIAQGtX1tNQUr6ismbFEwbXOPoOZXqFcrJcsVtnmc4wW5Pocj0t0mmv1RqR60VDG7McZ3uP1O7ezgvo8TEVC2+svP+jAysp3v4S7FeJVwqkrozZJb9c20zMthb1p5B8rPyeH7KvlZCor5n38HfHod8+Xx5O2U8EdNDHDA0MijaGsaNwAXy7k5Pb7s+jUVFaR6qCQQGMDkgKFpjo4adz7jQRnoTtmiaPgP1AcufJa+Dl7/pz7+DJzMXT54dinkrUM0XJByCQRtBG8KQWyx6bTUobBdA6eIbBK3429/P9e9ZuRw5S+qvo/jwaFGe49LOqLvbrnRXKPpKKpjlHEA7W943hZNlU63qS0aldsLFuL2bmQuZ0MoAQGMhADnAAkkADeUGyrXzTe2W5rmUr/fajcGwu6gPa78ZV6jh9tvWXRFK7Orr6R6s5ve75X3ufpa6XLR8ETdjGdw+63KMeFEdRX+zHuvna9zf+iLJXc4mza7dV3euZR0MevK7eTuYPqPILnbbGqPNI911ytlyxO0aO2OmsVvbTU7Q552yykbZHc+7kF8zkZEr580v+H0VFEaYcqJVcDsCAEAIDBAIwUBSNJtDy4vq7Q0ZO19ONmf5fwtXFz9fRb+TLycH++v8FGka6NzmPaWuacFrhggrXWmtoyn0emISpBiOSSJ4fFI9jxucxxBHiEcVJaZKeuqJqk0xvdIA33ps7RwnZreuw+qqTwMefjX6FmGZdHzv9SUh9ola0YmoKd54uZI5vptVd8Lh4kzuuJT8xR6P9pE2OpbI/GY/hQuFR8zPT4m/Ef8AJH1ftBu8uRBFSwA8Q0vI8Scei6x4XSu7bOUuI3Pskiv3G83K5f8A21s8rT8mthn+0bFcqoqq9kdFWy6yz3S2R5K7HLsISpIJXR/R+uv1RqUjNWFpxJO8dRv5PYPRV8jKroW5d/g70Y8739Pb5OuaPWGjsVGIKRuXu2yyu+KQ9vZ2L53IyJ3y5pf8N6iiFMdRJVcDsCAEAIAQAgBAQ970doLyNaoj6OfGBNHsd48/FWKMqyl/S+nwVrsaF3fv8lDu+h11oMvhZ75CPmi+IDtbv8srYpz6rOj6P7mXbhW19uqK28FryxwLXjYWkYIV5NNbRTfR6YhKAUqSBSgEJ7VIME7MoDattpuN1fq2+kknH1NGGj+o7Fzsvrq970e66Z2+1bLzYfZ1HGWzXuUSnf7vESG+Lt58MLJv4o30qWvuzTp4cl1te/sXungipoWwwRMjjYMNYwYACypNye31ZpxSitI9VBIIAQAgBACAEAIAQGCMoDUrrZRV7dWtpYph/raCfNe67bK3uD0c51Qn7lsr1w0Fspjc+FtRB2MlJH/LKu18Rv316lSfD6ddOhSL1ZoKBzhFLM7B+cj7ALUoyJWd0Z11Ea+zZE08LZpdRxIHYrMpaWzhGO3ouVk0Mt1YGunnqzngHtA/6rMuz7YPSSNGrBrl1bZaaHQ+w0Tg6OgZI8fNO4yeh2DwWfZnZFneX46F2GHTDql+epOMY1jQ1jQ1o3ADACqvq+pYQ6EggBACAEAID//Z"}`}
                  width={150}
                  height={150}
                  alt="prof"
                  className="rounded-full"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="lg:flex justify-between items-center space-x-2">
                <h1 className="text-2xl lg:text-4xl lg:min-w-36">
                  {user?.username ?? user?.name}
                </h1>
                <EditProfileForm />
              </div>
              <p>{user?.bio}</p>
              <div className="space-x-2">
                {user?.tag
                  ? user?.tag.map((val: string, idx: number) => (
                      <Badge
                        key={idx}
                        className="bg-highlight text-highlight2 font-bold"
                      >
                        {val}
                      </Badge>
                    ))
                  : null}
              </div>
            </div>
            <div className="flex items-center gap-2 lg:gap-10 text-center">
              <div>
                <h2 className="lg:text-3xl font-bold">
                  {user?.postCount ?? 0}
                </h2>
                <p className="text-sm lg:text-base text-white/60">Posts</p>
              </div>
              <div>
                <h2 className="lg:text-3xl font-bold">
                  {user?.followerCount ?? 0}
                </h2>
                <p className="text-xs lg:text-base text-white/60">Followes</p>
              </div>
              <div>
                <h2 className="lg:text-3xl font-bold">
                  {user?.followingCount ?? 0}
                </h2>
                <p className="text-xs lg:text-base text-white/60">Following</p>
              </div>
            </div>
          </div>

          <Tabs defaultValue="preview">
            <TabsList variant="line">
              <TabsTrigger value="preview" className="data text-white text-lg">
                <Grid2X2 />
                Post
              </TabsTrigger>
              <TabsTrigger value="saved" className="text-white text-lg">
                <Bookmark />
                Saved
              </TabsTrigger>
            </TabsList>
            <TabsContent value="preview">
              {myPostList?.length === 0 ? (
                <div className="place-content-center h-96 w-full">
                  <Camera className="mx-auto" size={100} />
                  <p className="text-center text-2xl">No Share Photos</p>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2 auto-rows-[200px]">
                  {myPostList?.map((item: any, idx: number) => (
                    <div
                      key={item._id}
                      className={`relative overflow-hidden rounded-lg bg-neutral-900`}
                    >
                      <Image
                        src={item.images}
                        fill
                        className="object-cover"
                        alt={`images ${idx}`}
                        sizes="(max-width: 768px) 33vw, 300px"
                        loading="eager"
                      />
                      {/* {item.isVideo && (
                      <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-black/50">
                        <Play className="h-3 w-3 fill-white text-white" />
                      </div>
                    )} */}
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>
            <TabsContent value="saved">
              <div className="grid grid-cols-3 gap-2 auto-rows-[200px]">
                {items.map((item, idx) => (
                  <div
                    key={item.id}
                    className={`relative overflow-hidden rounded-lg bg-neutral-900 ${
                      item.span === "tall" ? "row-span-2" : ""
                    } ${idx > 2 ? "hidden" : ""}`}
                  >
                    <Image
                      src={item.src}
                      fill
                      className="object-cover"
                      alt={item.alt}
                      sizes="(max-width: 768px) 33vw, 300px"
                      loading="eager"
                    />
                    {item.isVideo && (
                      <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-black/50">
                        <Play className="h-3 w-3 fill-white text-white" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </SidebarProvider>
  );
}
