"use client";

import ConversationMessage from "@/components/shared/ConversationMessage";
import NavigationMenuMobile from "@/components/shared/NavigationMenuMobile";
import { AppSidebar } from "@/components/shared/Sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Field, FieldLabel } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { SidebarProvider } from "@/components/ui/sidebar";
import { socket } from "@/lib/socket";
import { Plus } from "lucide-react";
import Image from "next/image";
import { useEffect } from "react";

const dummyDataListChat = [
  {
    picture: "/images/person1.avif",
    name: "Dian",
    last_msg: "omg lets to do thats",
    last_chat: "2m",
    total_unread_chat: 2,
  },
  {
    picture: "/images/person2.avif",
    name: "Rover",
    last_msg:
      "omg lets to do thats omg lets to do thats omg lets to do thats omg lets to do thats",
    last_chat: "2m",
    total_unread_chat: 0,
  },
  {
    picture: "/images/person3.avif",
    name: "Opang",
    last_msg: "omg lets to do thats",
    last_chat: "2m",
    total_unread_chat: 2,
  },
  {
    picture: "/images/person4.avif",
    name: "Sinta",
    last_msg: "omg lets to do thats",
    last_chat: "2m",
    total_unread_chat: 0,
  },
  {
    picture: "/images/person5.avif",
    name: "Oji",
    last_msg: "omg lets to do thats",
    last_chat: "2m",
    total_unread_chat: 0,
  },
];

export default function MessagePage() {
  useEffect(() => {
    socket.emit("get user active");

    socket.on("get user active", (users) => {
      console.log(users);
    });

    return () => {
      socket.off("get user active");
    };
  }, []);

  return (
    <SidebarProvider className="">
      <div className="hidden lg:block">
        <AppSidebar />
      </div>
      <div className="fixed bottom-0 left-0 z-30 lg:hidden">
        <NavigationMenuMobile />
      </div>
      <main className="w-full grid grid-cols-12 p-4 gap-8 ">
        <div className="col-span-2"></div>
        <div className="col-span-9 container space-y-8">
          <div className="grid grid-cols-12 gap-5">
            <Card className="col-span-4 bg-brand h-[50rem]">
              <CardHeader className="space-y-4">
                <div className="flex items-center justify-between">
                  <h1 className="text-2xl">Message</h1>
                  {/* <Button variant="outline" className="cursor-pointer">
                    <Plus />
                  </Button> */}
                </div>
                <Field>
                  <ButtonGroup>
                    <Input
                      id="input-button-group"
                      placeholder="Type to search..."
                    />
                    <Button variant="outline">Search</Button>
                  </ButtonGroup>
                </Field>
              </CardHeader>
              <Separator className="mb-2 bg-white/10" />
              <CardContent className="overflow-auto scrollbar-thin">
                {dummyDataListChat.map((chat, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between hover:bg-brand2 p-2 rounded-lg cursor-pointer"
                  >
                    <div className="flex items-center space-x-4">
                      <Image
                        src={chat.picture}
                        width={50}
                        height={50}
                        alt="prof"
                        className="rounded-full"
                      />
                      <div>
                        <p className="text-lg">{chat.name}</p>
                        <p className="text-white/70 truncate w-32">
                          {chat.last_msg}
                        </p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-brand5">{chat.last_chat}</p>
                      <Badge className="bg-brand5 text-white font-bold">
                        {chat.total_unread_chat}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
            <ConversationMessage />
          </div>
        </div>
      </main>
    </SidebarProvider>
  );
}
